/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"com.balta.examplelibrary",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["com.balta.examplelibrary.controls.Example"],elements:[]});return com.balta.examplelibrary},false);