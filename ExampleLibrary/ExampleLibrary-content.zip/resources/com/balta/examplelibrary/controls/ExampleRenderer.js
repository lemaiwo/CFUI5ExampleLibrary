/*!
 * ${copyright}
 */
sap.ui.define([],function(){"use strict";var e={};e.render=function(e,t){e.write("<div");e.writeControlData(t);e.addClass("sapRULTExample");e.writeClasses();e.write(">");e.write(sap.ui.getCore().getLibraryResourceBundle("com.balta.examplelibrary").getText("ANY_TEXT"));e.writeEscaped(t.getText());e.write("</div>")};return e},true);