/*!
 * ${copyright}
 */
sap.ui.define(["./../library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,a){"use strict";var t=r.extend("com.balta.examplelibrary.controls.Example",{metadata:{library:"com.balta.examplelibrary",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:a});return t},true);