/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"be.wl.examplelibrary",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["be.wl.examplelibrary.controls.Example"],elements:[]});return be.wl.examplelibrary},false);