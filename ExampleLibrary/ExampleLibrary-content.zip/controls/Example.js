/*!
 * ${copyright}
 */
sap.ui.define(["./../library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,t){"use strict";var a=r.extend("be.wl.examplelibrary.controls.Example",{metadata:{library:"be.wl.examplelibrary",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:t});return a},true);